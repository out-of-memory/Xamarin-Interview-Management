﻿using Newtonsoft.Json;
using RestBindAndNavigate.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace RestBindAndNavigate.ViewModel
{
    public class MainPageViewModel
    {
        private List<Question> questionList;

        public event PropertyChangedEventHandler PropertyChanged;
        
        public MainPageViewModel()
        {
        }

        public async Task GetQuestionsAsync(string url)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(url);
            var response = await client.GetAsync(client.BaseAddress);
            response.EnsureSuccessStatusCode();
            var jsonResult = response.Content.ReadAsStringAsync().Result;
            var questions = JsonConvert.DeserializeObject<List<Question>>(jsonResult);
            this.lstQuestions = questions;
        }

        public List<Question> lstQuestions
        {
            set
            {
                if (questionList != value)
                {
                    questionList = value;
                    OnPropertyChanged("lstQuestions");
                }
            }
            get
            {
                return questionList;
            }
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this,
                    new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}

