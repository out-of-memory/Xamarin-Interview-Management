﻿using RestBindAndNavigate.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace RestBindAndNavigate.View
{
    public partial class AnswerPage : ContentPage
    {
        public List<Answer> AnswerList { get; set; }
        public Question SelectedQuestion { get; set; }

        public AnswerPage(Question selectedQuestion)
        {
            var counter = 0;
            this.SelectedQuestion = selectedQuestion;
            this.AnswerList = new List<Answer>();
            foreach(string ans in selectedQuestion.AnswerOptions)
            {
                Answer newAnswer = new Answer();
                newAnswer.Answers = ans;
                newAnswer.Score = counter == SelectedQuestion.CorrectAnswer ? 1 : 0;
                newAnswer.IsCorrect = counter == SelectedQuestion.CorrectAnswer ?true : false;
                AnswerList.Add(newAnswer);
                counter++;
            }
            
            BindingContext = this;
            InitializeComponent(); ;
        }
    }
}
