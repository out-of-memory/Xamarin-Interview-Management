﻿using RestBindAndNavigate.CustomRenders;
using RestBindAndNavigate.Model;
using RestBindAndNavigate.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace RestBindAndNavigate.View
{
    public partial class MainPage : ContentPage
    {
        MainPageViewModel vm;

        public MainPage()
        {
            vm = new MainPageViewModel();
            GetQuestionsStack(0, 4);
        }

        private async Task GetQuestionsStack(int experience, int technology)
        {
            var url = string.Format("http://192.168.35.79/BasicQuestions/api/Questions/GetQuestions/0/4");
            await vm.GetQuestionsAsync(url);
            BindingContext = vm;
            InitializeComponent();
        }

        public void OnItemTapped(object o, ItemTappedEventArgs e)
        {
            if (e != null)
            {
                var question = e.Item as Question;
                Navigation.PushAsync(new AnswerPage(question));
            }
        }

        protected void OnImageTapped(object sender, EventArgs e)
        {
            var container = sender as Image;
            var buttonParent = container.Parent as ToggleButton;
            var a = buttonParent.CommandParameter;
            //var mi = ((MenuItem)sender); 
            // var mi = ((MenuItem)sender); var listItem = buttonParent.Parent;
            //var viewCell = listItem.Parent.Parent.Parent as ListView;
           
        }

    }
}