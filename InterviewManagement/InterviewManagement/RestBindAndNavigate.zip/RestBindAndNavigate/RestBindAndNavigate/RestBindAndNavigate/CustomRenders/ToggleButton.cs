﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace RestBindAndNavigate.CustomRenders
{
    public class ToggleButton : ContentView
    {
        public static readonly BindableProperty CommandProperty =
            BindableProperty.Create<ToggleButton, ICommand>(p => p.Command, null);

        public static readonly BindableProperty CommandParameterProperty =
            BindableProperty.Create<ToggleButton, object>(p => p.CommandParameter, null);

        public static readonly BindableProperty CheckedProperty =
            BindableProperty.Create<ToggleButton,bool>(p => p.Checked, false);

        public static readonly BindableProperty AnimateProperty =
            BindableProperty.Create<ToggleButton, bool>(p => p.Animate, false);

        public static readonly BindableProperty CheckedImageProperty =
            BindableProperty.Create<ToggleButton, ImageSource>(p => p.CheckedImage, null);

        public static readonly BindableProperty UnCheckedImageProperty =
            BindableProperty.Create<ToggleButton, ImageSource>(p => p.UnCheckedImage, null);


        public event EventHandler Tapped;

        private Image _toggleImage;

        public ToggleButton()
        {
            Initialize();
            var tgr = new TapGestureRecognizer();
            tgr.Tapped += (s, e) =>
            {
                if (Tapped != null)
                {
                    if (_toggleImage.Source == UnCheckedImage)
                    {
                        _toggleImage.Source = CheckedImage;
                        Checked = true;
                    }
                    else
                    {
                        _toggleImage.Source = UnCheckedImage;
                        Checked = false;
                    }
                    if (Animate)
                    {
                        this.ScaleTo(0.8, 50, Easing.Linear);
                        Task.Delay(100);
                        this.ScaleTo(1, 50, Easing.Linear);
                    }
                }
                this.Tapped(s, e);
            };

            this._toggleImage.GestureRecognizers.Add(tgr);
        }

        public ICommand Command
        {
            get { return (ICommand)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        public object CommandParameter
        {
            get { return GetValue(CommandParameterProperty); }
            set { SetValue(CommandParameterProperty, value); }
        }

        public bool Checked
        {
            get { return (bool)GetValue(CheckedProperty); }
            set { SetValue(CheckedProperty, value); }
        }

        public bool Animate
        {
            get { return (bool)GetValue(AnimateProperty); }
            set { SetValue(CheckedProperty, value); }
        }

        public ImageSource CheckedImage
        {
            get { return (ImageSource)GetValue(CheckedImageProperty); }
            set { SetValue(CheckedImageProperty, value); }
        }

        public ImageSource UnCheckedImage
        {
            get { return (ImageSource)GetValue(UnCheckedImageProperty); }
            set { SetValue(UnCheckedImageProperty, value); }
        }

        private void Initialize()
        {
            _toggleImage = new Image();
            Animate = true;
            _toggleImage.Source = UnCheckedImage;
            Content = _toggleImage;
        }

        protected override void OnParentSet()
        {
            base.OnParentSet();
            _toggleImage.Source = UnCheckedImage;
            Content = _toggleImage;
        }
    }
}

