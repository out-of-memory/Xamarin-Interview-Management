﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestBindAndNavigate.Model
{
    public class Question
    {
        public int QuestionId { get; set; }
        public string Questions { get; set; }
        public Nullable<bool> Favorite { get; set; }
        public List<string> AnswerOptions { get; set; }
        public Nullable<int> CorrectAnswer { get; set; }
    }
}
