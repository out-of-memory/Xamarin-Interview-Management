﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestBindAndNavigate.Model
{
    public class Answer
    {
        public string Answers { get; set; }
        public Nullable<int> Score { get; set; }
        public bool IsCorrect { get; set; }
    }
}
